Start-Process powershell.exe -Verb RunAs -ArgumentList ('noprofile -noexit -file "(0) -elevated' -f ($MyInvocation.MyCommand.Definition))
Add-Type -AssemblyName Microsoft.VisualBasic 
$glpi = [Microsoft.VisualBasic.Interaction]::InputBox('Introduce el numero de inventario del equipo', 'Numero de inventario', "$env:glpi")
$hostname = �HL-0�+$glpi 
$domain = �hiberus.local� 
$credential = Get-Credential 
Rename-Computer $hostname 
Set-itemproperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\policies\system' -Name 'EnableLUA' -Value 1
Set-itemproperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'AutoAdminLogon' -Value 0
Add-Computer �Domain $Domain �NewName $hostname �Credential $credential �Restart -Force 
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force
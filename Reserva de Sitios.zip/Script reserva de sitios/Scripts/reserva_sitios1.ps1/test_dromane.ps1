## variable nombre usuario
#$usuario = query user | Select-String '^>(\w+)' | ForEach-Object { $_.Matches[0].Groups[1].Value }

#$usuario1 = (((((query user) -replace " {2,}"," ") -split '\n')[1]) -split " ")
#$usuario = $usuario1[0].TrimStart(">")
$usuario1=(Get-WMIObject -ClassName Win32_ComputerSystem).Username
$usuario = $usuario1.Split("\")[1].ToLower()

## variable IPs
$direccion1 = Get-NetIPConfiguration | Where-Object{$_.ipv4defaultgateway -ne $null -and $_.NetAdapter.Status -ne 'Disconnected'}
$direccion = $direccion1.IPv4Address.ipaddress

# Verificar número de filas de $ dirección
#Si tiene una fila, directamente el Inovke-WebRequest
#Si tienes más de una, hacer tantos Invoke-WebRequest como filas

	foreach ($ip in $direccion)
		{
			Invoke-WebRequest -UseBasicParsing -Uri https://reservasitios.demohiberus.com/api/present/autopresent/$usuario@hiberus.com/$ip -Method POST
		}
		
#Log usuario+ip
$usuario+","+$direccion >> C:\Scripts\test_dromane.txt

